var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwz",
  1: "bertv",
  2: "bemoprstvz",
  3: "bemoprstvz",
  4: "_cefghiklmprstvwz",
  5: "_abcdeinoprstuvwz",
  6: "lt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

